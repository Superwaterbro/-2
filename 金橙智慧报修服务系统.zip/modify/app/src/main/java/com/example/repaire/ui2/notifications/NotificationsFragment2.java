package com.example.repaire.ui2.notifications;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.repaire.BeanRecord;
import com.example.repaire.MainActivity;
import com.example.repaire.MyDataBaseHelper;
import com.example.repaire.MyDataBaseManager;
import com.example.repaire.R;


public class NotificationsFragment2 extends Fragment {

    private NotificationsViewModel notificationsViewModel;
    private Button button2;
    private Button button1;
    BeanRecord record2;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        notificationsViewModel =
                ViewModelProviders.of(this).get(NotificationsViewModel.class);
        View root = inflater.inflate(R.layout.fragment_notifications2, container, false);
        final TextView textView = root.findViewById(R.id.xuhao2);
        final TextView textView2 = root.findViewById(R.id.xiangmu2);
        final TextView textView3 = root.findViewById(R.id.dilei);
        final TextView textView4 = root.findViewById(R.id.xiangxi);
        final TextView textView5 = root.findViewById(R.id.ren2);
        final TextView textView6 = root.findViewById(R.id.tel);
        final TextView textView7 = root.findViewById(R.id.qing);
        final TextView textView8 = root.findViewById(R.id.tai);
        final TextView textView9 = root.findViewById(R.id.name);
        final Button button2 = root.findViewById(R.id.ivDeleteText);
        final EditText edtSearch = root.findViewById(R.id.etSearch);

        notificationsViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);

            }
        });


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                int i = 0;


                String a[] = new String[10];
                String b[] = new String[10];
                String c[] = new String[10];
                String d[] = new String[10];
                String e[] = new String[10];
                String f[] = new String[10];
                String g[] = new String[10];
                String h[] = new String[10];

                String k[] = new String[10];

                MyDataBaseHelper helper = new MyDataBaseHelper(getActivity());
                SQLiteDatabase db = helper.getWritableDatabase();
                Cursor cursor = db.query("record", null, null, null, null, null, null);
                //调用moveToFirst()将数据指针移动到第一行的位置。
                if (cursor.moveToFirst()) {
                    do {
                        //然后通过Cursor的getColumnIndex()获取某一列中所对应的位置的索引
                        String xuhao = cursor.getString(cursor.getColumnIndex("xuhao"));
                        String dilei = cursor.getString(cursor.getColumnIndex("scope"));
                        String dizhi = cursor.getString(cursor.getColumnIndex("address"));
                        String xiangqing = cursor.getString(cursor.getColumnIndex("xiangqing"));
                        String name = cursor.getString(cursor.getColumnIndex("name"));
                        String phone = cursor.getString(cursor.getColumnIndex("phone"));
                        String state = cursor.getString(cursor.getColumnIndex("state"));
                        String serviceman = cursor.getString(cursor.getColumnIndex("serviceman"));
                        String sunhuai = cursor.getString(cursor.getColumnIndex("pro"));
                        if (i < 10) {
                            a[i] = xuhao;
                            b[i] = dilei;
                            c[i] = dizhi;
                            d[i] = xiangqing;
                            e[i] = name;
                            f[i] = phone;
                            g[i] = state;
                            h[i] = serviceman;
                            k[i] = sunhuai;

                            i++;
                        }
                    } while (cursor.moveToNext());
                }
                edtSearch.getText();


                cursor.close();
                for (i = 0; i < 10; i++) {


                    if (edtSearch.getText().toString().equals(a[i])) {

                        textView.setText(a[i]);
                        textView2.setText(d[i]);
                        textView3.setText(b[i]);
                        textView4.setText(c[i]);
                        textView5.setText(e[i]);
                        textView6.setText(f[i]);
                        textView7.setText(k[i]);
                        textView8.setText(g[i]);
                        textView9.setText(h[i]);
                    }

                }

            }
        });


        return root;
    }
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        final TextView textView = getActivity().findViewById(R.id.xuhao2);
        button1=(Button) getActivity().findViewById(R.id.oo);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                final AlertDialog dialog = builder.create();
                View dialogView = View.inflate(getActivity(), R.layout.chang, null);
                dialog.setView(dialogView);
                dialog.show();
                @SuppressLint("WrongViewCast")
                final EditText etstate = (EditText) dialogView.findViewById(R.id.edt_state);
                final EditText etren = (EditText) dialogView.findViewById(R.id.edt_ren);
                final String ets = etstate.getText().toString();
                final String etr = etren.getText().toString();

                Button btnConfirm = (Button) dialogView.findViewById(R.id.btn_confirm);
                Button btnRefuse = (Button) dialogView.findViewById(R.id.btn_refuse);




                btnConfirm.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (etstate.getText().toString().equals("") || etren.getText().toString().equals(" ")) {
                            Toast.makeText(getActivity(), "不能为空", Toast.LENGTH_SHORT).show();
                            return;
                        } else {

                            int i = 0;


                            String a[] = new String[10];
                            String b[] = new String[10];
                            String c[] = new String[10];
                            String d[] = new String[10];
                            String e[] = new String[10];
                            String f[] = new String[10];
                            String g[] = new String[10];
                            String h[] = new String[10];

                            String k[] = new String[10];
                            final EditText edtSearch = getActivity().findViewById(R.id.etSearch);
                            MyDataBaseHelper helper = new MyDataBaseHelper(getActivity());
                            SQLiteDatabase db = helper.getWritableDatabase();

                            Cursor cursor = db.query("record", null, null, null, null, null, null);
                            if (cursor.moveToFirst()) {
                                do {
                                    String xuhao = cursor.getString(cursor.getColumnIndex("xuhao"));
                                    String dilei = cursor.getString(cursor.getColumnIndex("scope"));
                                    String dizhi = cursor.getString(cursor.getColumnIndex("address"));
                                    String xiangqing = cursor.getString(cursor.getColumnIndex("xiangqing"));
                                    String name = cursor.getString(cursor.getColumnIndex("name"));
                                    String phone = cursor.getString(cursor.getColumnIndex("phone"));
                                    String state = cursor.getString(cursor.getColumnIndex("state"));
                                    String serviceman = cursor.getString(cursor.getColumnIndex("serviceman"));
                                    String sunhuai = cursor.getString(cursor.getColumnIndex("pro"));

                                    if (i < 10) {
                                        a[i] = xuhao;
                                        b[i] = dilei;
                                        c[i] = dizhi;
                                        d[i] = xiangqing;
                                        e[i] = name;
                                        f[i] = phone;
                                        g[i] = state;
                                        h[i] = serviceman;
                                        k[i] = sunhuai;

                                        i++;

                                        if ( textView.equals(a[i])) {
                                            g[i] = String.valueOf(etstate.getText().toString());
                                            h[i] = String.valueOf(etren.getText().toString());


                                            BeanRecord data = new BeanRecord();
                                            data.setState(g[i]);
                                            data.setScope(h[i]);
                                            MyDataBaseManager dbManager = new MyDataBaseManager(getActivity().getBaseContext());
                                            dbManager.addData(data);

                                        }

                                    }
                                }
                                while (cursor.moveToNext());
                            }
                            dialog.dismiss();
                        }
                    }



                    });
                btnRefuse.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
            }


        });
    }}


