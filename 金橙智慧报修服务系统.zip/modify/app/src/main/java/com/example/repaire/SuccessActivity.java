package com.example.repaire;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;


import android.annotation.SuppressLint;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.repaire.ui.home.HomeFragment;

public class SuccessActivity extends AppCompatActivity {

    private Button btnConfirm;
    private  Button btnRefuse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success);


        Button btnConfirm=(Button) findViewById(R.id.btn_confirm);
        Button btnRefuse=(Button) findViewById(R.id.btn_refuse);

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onClick(View view) {
                Intent intent;
                intent = new Intent(SuccessActivity.this, HomePageActivity.class);
                startActivity(intent);
            }
        });

        btnRefuse.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onClick(View view) {
                Intent intent;
                intent = new Intent(SuccessActivity.this, HomePageActivity.class);
                startActivity(intent);
            }
        });


    }
}


   /* Fragment fragment=new Fragment();
    FragmentManager fragmentManager=getFragmentManager();
    FragmentTransaction ft=fragmentManager.beginTransaction();
                ft.replace(R.layout.fragment_home, fragment);
                        ft.commit();*/