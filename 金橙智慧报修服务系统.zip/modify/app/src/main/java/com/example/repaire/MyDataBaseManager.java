package com.example.repaire;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class MyDataBaseManager {
    private MyDataBaseHelper helper;
    private SQLiteDatabase db;

    public MyDataBaseManager(Context context) {
        helper = new MyDataBaseHelper(context);
        db = helper.getWritableDatabase();
    }

    public void addData(BeanRecord data) {
        addContent(data);
    }

    private void addContent(BeanRecord data) {
        ContentValues values = new ContentValues();

        values.put("xuhao",data.getXuhao());

        values.put("scope", data.getScope());

        values.put("address", data.getAddress());

        values.put("pro", data.getPro());

        values.put("xiangqing", data.getXiangqing());

        values.put("name", data.getName());

        values.put("phone", data.getPhone());

        values.put("state", data.getState());

        values.put("serviceman", data.getServiceman());



        db.insert("record", null, values);
    }

    public ArrayList<BeanRecord> queryALLContent() {
        ArrayList<BeanRecord> datas = new ArrayList<>();
        Cursor c = db.query("record", null, null, null, null, null, null);
        while (c.moveToNext()) {
            BeanRecord data = null;


            String xuhao = c.getString(c.getColumnIndex("xuhao"));
            String scope = c.getString(c.getColumnIndex("scope"));
            String address = c.getString(c.getColumnIndex("address"));
            String pro = c.getString(c.getColumnIndex("pro"));
            String xiangqing = c.getString(c.getColumnIndex("xiangqing"));
            String name = c.getString(c.getColumnIndex("name"));
            String phone = c.getString(c.getColumnIndex("phone"));
            String state = c.getString(c.getColumnIndex("state"));
            String serviceman = c.getString(c.getColumnIndex("serviceman"));

            data = new BeanRecord(xuhao,scope,address,pro,xiangqing,name,phone,state,serviceman);
            datas.add(data);
        }
        c.close();
        return datas;
    }

}
