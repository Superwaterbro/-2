package com.example.repaire.ui2.dashboard;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;


import android.os.Bundle;
import android.os.Handler;


import com.example.repaire.BeanRecord;
import com.example.repaire.MyDataBaseManager;
import com.example.repaire.R;
import com.example.repaire.RecordAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.ArrayList;
import java.util.List;

public class DashboardFragment2 extends Fragment {

    private MyDataBaseManager dbManager;
    private ListView listView;
    private List<BeanRecord> datas = new ArrayList<>();
    EditText edtSearch;
    ImageView ivDeleteText;
    private RecordAdapter adapter;
    ArrayList<String> xuhao = new ArrayList<String>();
    ArrayList<String> pro = new ArrayList<String>();
    ArrayList<String> state = new ArrayList<String>();
    Handler myhandler = new Handler();
    private DashboardViewModel dashboardViewModel;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        dashboardViewModel =
                ViewModelProviders.of(this).get(DashboardViewModel.class);
        View root = inflater.inflate(R.layout.fragment_dashboard2, container, false);
        final TextView textView = root.findViewById(R.id.text_dashboard);


        final EditText edtSearch = root.findViewById(R.id.etSearch);
        final ImageView ivDeleteText = root.findViewById(R.id.ivDeleteText);

        dashboardViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);

            }
        });


        dbManager = new MyDataBaseManager(getActivity().getBaseContext());

        initDatas();
        edtSearch.addTextChangedListener(new TextWatcher() {
            public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {

            }

            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
            }

            public void afterTextChanged(Editable s) {
                if (s.length() == 0) {
                    ivDeleteText.setVisibility(View.GONE);
                } else {
                    ivDeleteText.setVisibility(View.VISIBLE);
                }
                myhandler.post(eChanged);
            }
        });


        ivDeleteText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtSearch.setText("");
            }
        });

        adapter = new RecordAdapter(getActivity(), R.layout.list, datas);
        adapter.notifyDataSetChanged();
        final ListView listView = root.findViewById(R.id.listview);
        listView.setAdapter(adapter);
        listView.setTextFilterEnabled(true);


        return root;
    }


    Runnable eChanged = new Runnable() {
        @Override
        public void run() {
            String data = edtSearch.getText().toString();
            datas.clear();
            getmDataSub(datas, data);
            adapter.notifyDataSetChanged();
        }
    };

    private void getmDataSub(List<BeanRecord> datas, String data) {
        int length = pro.size();
        for (int i = 0; i < length; ++i) {
            if (pro.get(i).contains(data) || xuhao.get(i).contains(data) || state.get(i).contains(data)) {
                BeanRecord item = new BeanRecord();
                item.setScope(xuhao.get(i));
                item.setPro(pro.get(i));
                item.setState(state.get(i));

                datas.add(item);
            }
        }
    }


    private void initDatas() {
        datas = dbManager.queryALLContent();
        for (BeanRecord d : datas) {
            if (d != null) {

                xuhao.add(d.getXuhao());

                pro.add(d.getScope());

                state.add(d.getState());

            }

        }
    }
}