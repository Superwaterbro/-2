package com.example.repaire;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

public class RecordAdapter extends ArrayAdapter {
    //adapter是数据与ui之间的桥梁，它把后台数据与前端ui连接到一起，是一个展示数据的载体。
    private int resourceid;
    public RecordAdapter(Context context, int id, List<BeanRecord> objects){
        super(context,id,objects);
        resourceid = id;
    }
    public View getView(int position, View convertView, ViewGroup parent){
        BeanRecord data= (BeanRecord) getItem(position);
        View view;
        if(convertView==null){
            view= LayoutInflater.from(getContext()).inflate(resourceid,null);
        }
        else{
            view=convertView;
        }

        TextView xuhao=(TextView) view.findViewById(R.id.xuhao);
        TextView prog=(TextView) view.findViewById(R.id.prog);
        TextView zhuangtai=(TextView) view.findViewById(R.id.zhuangtai);


        xuhao.setText(data.getXuhao());
        prog.setText(data.getPro());
        zhuangtai.setText(data.getState());


        return view;
    }

}
