package com.example.repaire.ui2.home;


import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.repaire.MyDataBaseHelper;
import com.example.repaire.NewsActivity;
import com.example.repaire.R;

public class HomeFragment2 extends Fragment {

    private HomeViewModel homeViewModel;
    private Button button;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home2, container, false);
        final TextView textView = root.findViewById(R.id.text_home);
        final TextView textView2 = root.findViewById(R.id.text11);
        final TextView textView3 = root.findViewById(R.id.text22);
        homeViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });

        String aa  ="";
        MyDataBaseHelper helper = new MyDataBaseHelper(getActivity());
        SQLiteDatabase db = helper.getWritableDatabase();
        int oo = 0;
        String bb  ="";
        Cursor cursor = db.query("record", null, null, null, null, null, null);
        //调用moveToFirst()将数据指针移动到第一行的位置。
        if (cursor.moveToFirst()) {
            do {

                String xuhao = cursor.getString(cursor.getColumnIndex("xuhao"));
                String state = cursor.getString(cursor.getColumnIndex("state"));
                if(state.equals("未处理")){

                    oo++;
                    bb=String.valueOf(oo);
                }
                aa=xuhao;
            } while (cursor.moveToNext());
        }



        cursor.close();


        textView2.setText(aa);
        textView3.setText(bb);
        return root;
    }
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        button=(Button) getActivity().findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent;
                intent = new Intent(getActivity(), NewsActivity.class);
                startActivity(intent);
            }
        });
    }}