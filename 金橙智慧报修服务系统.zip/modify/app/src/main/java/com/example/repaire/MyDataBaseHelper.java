package com.example.repaire;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDataBaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME="fix.db";
    private static final int DATABASE_VERSION = 1;

    public MyDataBaseHelper(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }
    public void onCreate(SQLiteDatabase db){
        db.execSQL
                ("CREATE TABLE IF NOT EXISTS record"+
                        "(id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                        "xuhao TEXT,"+
                        "scope TEXT,"+
                        "address TEXT,"+
                        "pro TEXT,"+
                        "xiangqing TEXT,"+
                        "name TEXT,"+
                        "phone TEXT,"+
                        "state TEXT,"+
                        "serviceman TEXT)");
    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("drop table if exists record");
    }

}
