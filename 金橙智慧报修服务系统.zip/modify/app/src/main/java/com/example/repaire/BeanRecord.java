package com.example.repaire;

public class BeanRecord {
    String scope;
    String address;
    String pro;
    String xiangqing;
    String name;
    String phone;
    String state="未处理";
    String serviceman="无";
    String xuhao;
    public BeanRecord(){}

    public BeanRecord(String xuhao,String scope,String address,String pro, String xiangqing,String name, String phone,String state,String serviceman){
        this.xuhao=xuhao;
        this.scope=scope;
        this.address=address;
        this.pro=pro;
        this.xiangqing=xiangqing;
        this.name=name;
        this.phone=phone;
        this.state=state;
        this.serviceman=serviceman;
    }

    public String getXuhao() {
        return xuhao;
    }

    public String getScope() {
        return scope;
    }


    public String getAddress() {
        return address;
    }

    public String getPro() {
        return pro;
    }

    public String getXiangqing() {
        return xiangqing;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getState(){return state;}

    public String getServiceman(){return serviceman;}



    public void setXuhao(String xuhao) { this.xuhao=xuhao; }

    public void setScope(String scope) {
        this.scope =scope;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPro(String pro) {
        this.pro =pro;
    }

    public void setXiangqing(String xiangqing) {
        this.xiangqing=xiangqing;
    }

    public void setName(String name) {
        this.name =name;
    }

    public void setPhone(String phone) {
        this.phone =phone;
    }

    public void setState(String state) {
        this.state =state;
    }

    public void setServiceman(String serviceman) {
        this.serviceman =serviceman;
    }


}
