package com.example.repaire.ui.dashboard;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.example.repaire.BeanRecord;
import com.example.repaire.MyDataBaseHelper;
import com.example.repaire.MyDataBaseManager;
import com.example.repaire.R;
import com.example.repaire.SuccessActivity;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DashboardFragment extends Fragment {

    private DashboardViewModel dashboardViewModel;
    private EditText editText5;
    private EditText editText6;
    private EditText editText1;
    private EditText editText2;
    private EditText editText3;
    private EditText editText4;
    View view;
    private Button button;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        dashboardViewModel =
                ViewModelProviders.of(this).get(DashboardViewModel.class);
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);
        return view;
    }


    public void onActivityCreated(Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);

        Button button=getActivity().findViewById(R.id.button);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               int lala[] = new int[10];
                MyDataBaseHelper helper = new MyDataBaseHelper(getActivity());
                SQLiteDatabase db = helper.getWritableDatabase();
                Cursor cursor = db.query("record", null, null, null, null, null, null);
                //调用moveToFirst()将数据指针移动到第一行的位置。
                if (cursor.moveToFirst()) {
                    do{

                        //然后通过Cursor的getColumnIndex()获取某一列中所对应的位置的索引
                        int i = cursor.getInt(cursor.getColumnIndex("xuhao"));
                        lala[0]=i+1;

                    } while (cursor.moveToNext());
                }
                cursor.close();

                String xuhao = String.valueOf(lala[0]);
                EditText editText5=(EditText) getActivity().findViewById(R.id.et5);
                EditText editText1=(EditText) getActivity().findViewById(R.id.et1);
                EditText editText6=(EditText) getActivity().findViewById(R.id.et6);
                EditText editText2=(EditText) getActivity().findViewById(R.id.et2);
                EditText editText3=(EditText) getActivity().findViewById(R.id.et3);
                EditText editText4=(EditText) getActivity().findViewById(R.id.et4);

                final String stret5=String.valueOf(editText5.getText().toString());
                final String stret=String.valueOf(editText1.getText().toString());
                final String stret6=String.valueOf(editText6.getText().toString());
                final String stret1=String.valueOf(editText2.getText().toString());
                final String stret2=String.valueOf(editText3.getText().toString());
                final String stret3=String.valueOf(editText4.getText().toString());

                editText5.getText();
                editText1.getText();
                editText6.getText();
                editText2.getText();
                editText3.getText();
                editText4.getText();


                BeanRecord data=new BeanRecord();
                data.setXuhao(xuhao);
                data.setScope(stret5);
                data.setAddress(stret);
                data.setPro(stret6);
                data.setXiangqing(stret1);
                data.setName(stret2);
                data.setPhone(stret3);

                MyDataBaseManager dbManager=new MyDataBaseManager(getActivity().getBaseContext());
                dbManager.addData(data);

                Intent intent;
                intent = new Intent(getActivity(), SuccessActivity.class);
                startActivity(intent);

            }
    });

    }




}
